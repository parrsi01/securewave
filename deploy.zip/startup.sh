#!/bin/bash

# Navigate to app directory
cd /home/site/wwwroot

# Activate virtual environment
source antenv/bin/activate

# Export environment variables
export PYTHONUNBUFFERED=1
export PORT=8000

# Start Gunicorn
exec gunicorn --bind=0.0.0.0:$PORT \
    --timeout 600 \
    --workers=1 \
    --worker-class uvicorn.workers.UvicornWorker \
    --access-logfile - \
    --error-logfile - \
    --log-level info \
    main:app
