"""Routes package for SecureWave VPN"""
