SecureWave portable Linux package

This portable package can launch the SecureWave UI, sign in, and show account
state. Full-device VPN routing requires the root-owned SecureWave helper service.

Install the SecureWave .deb package for full no-prompt VPN connect/disconnect.
The portable tar/zip package intentionally does not install privileged routing
services, systemd units, or Unix sockets.
